package miniProjPackage;

import java.sql.*;
import java.util.Scanner;

public class product extends DatabaseOperation { // Inheritance: Product is a DatabaseOperation
    public product() throws SQLException {
        super();                      
    }
    
    public static void main(String[] args) {
        try {
            product product = new product();
            product.run(); // Polymorphism: we can call 	() on a Product because it's a DatabaseOperation
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
    
    @Override // Polymorphism: Product provides its own implementation of run()
    public void run()  { // Declare SQLException
        Scanner scanner = new Scanner(System.in);
        PreparedStatement pstmt;

        try { // Include a try-catch block for SQLException
            while(true) {
                System.out.println("Please select an operation:");
                System.out.println("1. Create a new product");
                System.out.println("2. View all products");
                System.out.println("3. Update a product's cost");
                System.out.println("4. Delete a product");
                System.out.println("5. View Customer details");
                System.out.println("6. View Orders");
                System.out.println("7. Exit");

                int choice = scanner.nextInt();

                switch (choice) {

                    case 1: // CREATE
                        System.out.println("Enter new product ID:");
                        int prodId = scanner.nextInt();
                        System.out.println("Enter new product name:");
                        scanner.nextLine(); 
                        String prodName = scanner.nextLine();
                        System.out.println("Enter new product cost:");
                        while (!scanner.hasNextDouble()) {
                            System.out.println("That's not a valid number! Try again:");
                            scanner.next(); // this is important!
                        }
                        double prodCost = scanner.nextDouble();

                        String insertProduct = "INSERT INTO product (prodId, prodName, cost) VALUES (?, ?, ?)";
                        pstmt = conn.prepareStatement(insertProduct);
                        pstmt.setInt(1, prodId);
                        pstmt.setString(2, prodName);
                        pstmt.setDouble(3, prodCost);
                        pstmt.executeUpdate();
                        System.out.println("Product has been added successfully.");
                        break;

                    case 2: // READ
                        Statement stmt = conn.createStatement();
                        ResultSet rs = stmt.executeQuery("SELECT * FROM product");
                        while (rs.next()) {
                            System.out.println("Product ID: " + rs.getInt("prodId") + ", Product Name: " + rs.getString("prodName") + ", Cost: " + rs.getDouble("cost"));
                        }
                        break;

                    case 3: // UPDATE
                        System.out.println("Enter product ID to update:");
                        prodId = scanner.nextInt();
                        System.out.println("Enter new product cost:");
                        prodCost = scanner.nextDouble();

                        String updateProduct = "UPDATE product SET cost = ? WHERE prodId = ?";
                        pstmt = conn.prepareStatement(updateProduct);
                        pstmt.setDouble(1, prodCost);
                        pstmt.setInt(2, prodId);
                        pstmt.executeUpdate();
                        System.out.println("Product price has been updated successfully.");
                        break;

                    case 4: // DELETE
                        System.out.println("Enter product ID to delete:");
                        prodId = scanner.nextInt();

                        String deleteProduct = "DELETE FROM product WHERE prodId = ?";
                        pstmt = conn.prepareStatement(deleteProduct);
                        pstmt.setInt(1, prodId);
                        pstmt.executeUpdate();
                        System.out.println("Product has been deleted successfully.");
                        break;
                    
                    case 5: // PRINT CUSTOMER TABLE
                        Statement customerStmt = conn.createStatement();
                        ResultSet customerRs = customerStmt.executeQuery("SELECT * FROM customer");
                        System.out.println("Customer details:");
                        while (customerRs.next()) {
                            System.out.println("Customer ID: " + customerRs.getInt("cId") + ", Customer Name: " + customerRs.getString("cName") + ", Mobile Number: " + customerRs.getString("mobileNo") + ", Address: " + customerRs.getString("address"));
                        }
                        break;

                    case 6: // PRINT ORDER TABLE
                        Statement orderStmt = conn.createStatement();
                        ResultSet orderRs = orderStmt.executeQuery("SELECT * FROM orders");
                        System.out.println("Order details:");
                        while (orderRs.next()) {
                            System.out.println("Order ID: " + orderRs.getInt("ordId") + ", Order Name: " + orderRs.getString("ordName") + ", Cost: " + orderRs.getDouble("cost") + ", Product ID: " + orderRs.getInt("prodId") + ", Customer ID: " + orderRs.getInt("cId"));
                        }
                        break;
                        
                    case 7: // EXIT
                        System.out.println("Exiting...");
                        conn.close();
                        scanner.close();
                        System.exit(0);

                    default:
                        System.out.println("Invalid choice! Please choose a number between 1 and 5.");
                        break;
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
}

	
